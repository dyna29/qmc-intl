<link rel="stylesheet" type="text/css" media="screen" href="<?= ($BASE) ?>/css/jquery-ui.min.css" />
<link rel="stylesheet" type="text/css" media="screen" href="<?= ($BASE) ?>/css/ui.jqgrid.min.css" />
<link rel="stylesheet" type="text/css" media="screen" href="<?= ($BASE) ?>/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" media="screen" href="<?= ($BASE) ?>/css/select2.css" />
<link rel="stylesheet" type="text/css" media="screen" href="<?= ($BASE) ?>/css/style.min.css" />
<!--[if lt IE 9]>
	<link rel="stylesheet" href="<?= ($BASE) ?>/css/ie.css" type="text/css" media="screen" />
	<script src="<?= ($BASE) ?>/js/html5.js"></script>
	<![endif]-->
<script src="<?= ($BASE) ?>/js/jquery.min.js" type="text/javascript"></script>
<script src="<?= ($BASE) ?>/js/jquery-ui.min.js" type="text/javascript"></script>
<script src="<?= ($BASE) ?>/js/jquery.jqgrid.min.js" type="text/javascript"></script>
<script src="<?= ($BASE) ?>/js/lodash.min.js" type="text/javascript"></script>
<script src="<?= ($BASE) ?>/js/select2.js" type="text/javascript"></script>
<script src="<?= ($BASE) ?>/js/autoNumeric.js" type="text/javascript"></script>
<script src="<?= ($BASE) ?>/js/moment.min.js" type="text/javascript"></script>

<script src="<?= ($BASE) ?>/js/library.min.js" type="text/javascript"></script>

<script src="<?= ($BASE) ?>/js/locale-<?= (strtolower($APP['lang'])) ?>.min.js" type="text/javascript"></script>
<script type="text/javascript">
  $.i18n.load(fuwafuwa_lib_translation);
  var base_url = '<?= ($BASE) ?>';
  var print_header = `<?= ($APP['printHeader']) ?>`;
  var company_logo = `<?= ($BASE) ?>/<?= ($COMPANY['logoImage']) ?>`;
  var company_name = `<?= ($COMPANY['name']) ?>`;
  var company_address = `<?= ($COMPANY['address']) ?>`;
  var company_phone = `<?= ($COMPANY['phone']) ?>`; 
  <?php if ($APP['lang'] && $APP['lang'] != 'EN'): ?>
  $.jgrid.formatter.number = $.jgrid.locales.<?= (strtolower($APP['lang'])) ?>.formatter.number;
  $.jgrid.formatter.currency = $.jgrid.locales.<?= (strtolower($APP['lang'])) ?>.formatter.currency;
  moment.locale('<?= (strtolower($APP['lang'])) ?>'); // date time library with ID locale
  <?php endif; ?>

</script>
<script src="<?= ($BASE) ?>/js/fuwafuwa.min.js" type="text/javascript"></script>
