<body>
  <h1><?= ($ERROR['status']) ?></h1>
  <pre><?= ($ERROR['text']) ?></pre>
  <?php if ($ERROR['code'] == 500): ?>
    <code style="white-space: pre-wrap;">
		<?= ($this->raw($ERROR['trace']))."
" ?>
		</code>
  <?php endif; ?>
  <?php if ($ERROR['code'] == 401): ?>
    <?php echo $this->render('login.htm',NULL,get_defined_vars(),0); ?>
  <?php endif; ?>
</body>
