<?php $login_include=Theme::getTemplateFile('login.htm'); ?>
  <?php echo $this->render($login_include,NULL,get_defined_vars(),0); ?>
