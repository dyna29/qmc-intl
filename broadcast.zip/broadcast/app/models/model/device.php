<?php

namespace Model;
  
class Device extends \BaseModel {
  function __construct() {
    parent::__construct(\Fuwafuwa\Db::connection(), 'device');
    $this->keys = 'id';
  }
  
}