<?php

namespace Model;
  
class Broadcast extends \BaseModel {
  function __construct() {
    parent::__construct(\Fuwafuwa\Db::connection(), 'broadcast');
    $this->keys = 'id';
  }
  
}