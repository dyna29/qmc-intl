<?php
/**
 * app/controllers/fuwafuwa/util.php
 *
 * @package default
 */


/**
 * Fungsi compare untuk mengurutkan array
 *
 * @author Azrul Azwar
 * @param unknown $indexes indeks dari array yang diurutkan, negatif berarti menurun. 
 *                Contoh: [1,-3] => urutkan indeks ke-2, lalu ke-4 secara menurun
 * @return function
 */
function create_compare_function($indexes) {
  for ($i=0;$i<count($indexes);$i++) {
    $idx = $indexes[$i];
    if ($idx < 0) {
      $idx = -$idx;
      $op = '>';
    } else {
      $op = '<';
    }
    $pre .= str_repeat(' ', $i) . 'if($a['.$idx.'] == $b['.$idx.']) {'."\n";
    if ($i == count($indexes)-1) {
      $pre .= str_repeat(' ', $i+1) . "return 0;\n";
    }
    $suf = str_repeat(' ', $i) . '}' . "\n" .
      str_repeat(' ', $i) . 'return ($a['.$idx.']'.$op.'$b['.$idx.'])?-1:1;' . "\n$suf";
  }
  return create_function('$a, $b', "$pre$suf");
}


/**
 * Fungsi compare untuk mengurutkan array yang sudah dalam format jqGrid
 *
 * @author Azrul Azwar
 * @param unknown $indexes
 * @return function
 */
function create_compare_function_a($indexes) {
  // negative = reverse
  for ($i=0;$i<count($indexes);$i++) {
    $idx = $indexes[$i];
    if ($idx < 0) {
      $idx = -$idx;
      $op = '>';
    } else {
      $op = '<';
    }
    $pre .= str_repeat(' ', $i) . 'if($a[cell]['.$idx.'] == $b[cell]['.$idx.']) {'."\n";
    if ($i == count($indexes)-1) {
      $pre .= str_repeat(' ', $i+1) . "return 0;\n";
    }
    $suf = str_repeat(' ', $i) . '}' . "\n" .
      str_repeat(' ', $i) . 'return ($a[cell]['.$idx.']'.$op.'$b[cell]['.$idx.'])?-1:1;' . "\n$suf";
  }
  return create_function('$a, $b', "$pre$suf");
}


/**
 * Untuk menampilkan tabel jqgrid sederhana
 *
 *
 * @author Azrul Azwar
 * @param unknown $tableName
 * @param unknown $fieldList
 * @param unknown $conds        (optional)
 * @param unknown $replaceRules (optional)
 * @return void
 */
function record_list($tableName, $fieldList, $conds=[], $replaceRules=[]) {
  $f3 = \Base::instance();
  $page = $f3['REQUEST.page']; // get the requested page
  $limit = $f3['REQUEST.rows']; // get how many rows we want to have into the grid
  $sidx = $f3['REQUEST.sidx']; // get index row - i.e. user click to sort
  $sord = $f3['REQUEST.sord']; // get the direction

  //if(!$sidx) $sidx = "kode";
  if (!$limit) $limit = 50;
  if (!$page) $page = 1;
  if (count($replaceRules) && $replaceRules[$sidx]) {
    $sidx = $replaceRules[$sidx];
  }

  $lcond = $conds;
  if ($f3['REQUEST._search']) {
    $filters = json_decode($f3['REQUEST.filters'], true);
    foreach ((array)$filters['rules'] as $rule) {
      $data = escapeSQLString($rule[data]);
      switch ($rule['op']) {
      case "eq": $lcond[] = "$rule[field] = '$data'"; break;
      case "ne": $lcond[] = "$rule[field] != '$data'"; break;
      case "lt": $lcond[] = "$rule[field] < '$data'"; break;
      case "le": $lcond[] = "$rule[field] <= '$data'"; break;
      case "gt": $lcond[] = "$rule[field] > '$data'"; break;
      case "ge": $lcond[] = "$rule[field] >= '$data'"; break;
      case "in": $lcond[] = "$rule[field] IN ($data)"; break;
      case "ni": $lcond[] = "$rule[field] NOT IN ($data)"; break;
      case "bw": $lcond[] = "$rule[field] LIKE '$data%'"; break;
      case "bn": $lcond[] = "$rule[field] NOT LIKE '$data%'"; break;
      case "ew": $lcond[] = "$rule[field] LIKE '%$data'"; break;
      case "en": $lcond[] = "$rule[field] NOT LIKE '%$data'"; break;
      case "cn": $lcond[] = "$rule[field] LIKE '%$data%'"; break;
      case "nc": $lcond[] = "$rule[field] NOT LIKE '%$data%'"; break;
      }
    }
  }

  if (count($lcond)) {
    $cond = "WHERE " . join(" $filters[groupOp] ", $lcond);
  }

  $sql_count = "SELECT count(1) FROM $tableName $cond";
  $count = FSQL1($sql_count);
  if ($count) {
    $total_pages = ceil($count/$limit);
  } else {
    $total_pages = 0;
  }
  if ($page > $total_pages) $page = $total_pages;
  $start = $limit*$page - $limit; // do not put $limit*($page - 1)
  if ($start < 0) $start = 0;
  $fields = is_array($fieldList) ? join(", ", $fieldList) : $fieldList;
  if ($sidx) {
    $order = "ORDER BY $sidx $sord";
  }
  $sql_select = "SELECT $fields
	  FROM $tableName
		$cond
	  $order LIMIT $start, $limit";
  //print "<pre>$sql_select"; die();
  $result = FSQL($sql_select);
  array2json($result?:[], 0, $count, $page, $total_pages);
}


/**
 * menampilkan tabel jqgrid yang kompleks
 *
 * @author Azrul Azwar
 * @param unknown $from_join
 * @param unknown $fieldList
 * @param unknown $conds          (optional)
 * @param unknown $replaceRules   (optional)
 * @param unknown $simpleCountSql (optional)
 * @param unknown $key_index      (optional)
 * @param unknown $print_sql      (optional)
 * @return void
 */
function record_list2($from_join, $fieldList, $conds=[], $replaceRules=[],
  $simpleCountSql="", $key_index=0, $print_sql=false) {

  $f3 = \Base::instance();
  $page = $f3['REQUEST.page']; // get the requested page
  $limit = $f3['REQUEST.rows']; // get how many rows we want to have into the grid
  $sidx = $f3['REQUEST.sidx']; // get index row - i.e. user click to sort
  $sord = $f3['REQUEST.sord']; // get the direction

  if (!$sidx) $sidx = "kode";
  if (!$limit) $limit = 50;
  if (!$page) $page = 1;
  if ($replaceRules[$sidx]) {
    $sidx = $replaceRules[$sidx];
  }
  $lcond = $conds;
  if ($f3['REQUEST._search']) {
    $filters = json_decode($f3['REQUEST.filters'], true);
    foreach ((array)$filters['rules'] as $rule) {
      $field = $rule['field'];
      if ($replaceRules[$field]) {
        $field = $replaceRules[$field];
      }
      $data = escapeSQLString($rule[data]);
      switch ($rule['op']) {
      case "eq": $lcond[] = "$field = '$data'"; break;
      case "ne": $lcond[] = "$field != '$data'"; break;
      case "lt": $lcond[] = "$field < '$data'"; break;
      case "le": $lcond[] = "$field <= '$data'"; break;
      case "gt": $lcond[] = "$field > '$data'"; break;
      case "ge": $lcond[] = "$field >= '$data'"; break;
      case "in": $lcond[] = "$field IN ($data)"; break;
      case "ni": $lcond[] = "$field NOT IN ($data)"; break;
      case "bw": $lcond[] = "$field LIKE '$data%'"; break;
      case "bn": $lcond[] = "$field NOT LIKE '$data%'"; break;
      case "ew": $lcond[] = "$field LIKE '%$data'"; break;
      case "en": $lcond[] = "$field NOT LIKE '%$data'"; break;
      case "cn": $lcond[] = "$field LIKE '%$data%'"; break;
      case "nc": $lcond[] = "$field NOT LIKE '%$data%'"; break;
      }
    }
    $cop = $filters['groupOp'] ?: 'AND';
  } else {
    $cop = 'AND';
  }

  if (count($lcond)) {
    $cond = "WHERE " . join(" $cop ", $lcond);
  }
  if ($simpleCountSql && !$cond) {
    $sql_count = $simpleCountSql;
  } else {
    $sql_count = "SELECT count(1) FROM $from_join $cond";
  }
  //print "<pre>$sql_count"; die();
  $count = FSQL1($sql_count);
  if ($count) {
    $total_pages = ceil($count/$limit);
  } else {
    $total_pages = 0;
  }
  if ($page > $total_pages) $page = $total_pages;
  $start = $limit*$page - $limit; // do not put $limit*($page - 1)
  if ($start < 0) $start = 0;
  $fields = is_array($fieldList) ? join(", ", $fieldList) : $fieldList;
  $sql_select = "SELECT $fields FROM $from_join
		$cond
	  ORDER BY $sidx $sord LIMIT $start, $limit";
  if ($print_sql) {
    print "<pre>$sql_select"; die();
  }
  $result = FSQL($sql_select);
  array2json($result, $key_index, $count, $page, $total_pages);
}


/**
 * Fungsi untuk membungkus array ke dalam format jqGrid.
 * @param unknown $rows array dalam format jqgrid
 * @param unknown $count jumlah record (optional)
 * @param unknown $page jumlah halaman (optional)
 * @param unknown $total_pages total halaman (optional)
 * @return unknown
 */
function jqgridWrap($rows=[], $count=0, $page=1, $total_pages=1) {
  if (!$count) $count = count($rows);
  $arr = array(
    "page" => $page,
    "total" => $total_pages,
    "records" => $count,
    "rows" => $rows,
  );
  $result = json_encode($arr);
  print $result;
  return $result;
}


/**
 * konversi array biasa ke dalam format jqGrid
 *
 * @author Azrul Azwar
 * @param unknown $array
 * @param unknown $id_index index kolom yang dijadikan key (optional)
 * @param unknown $count       (optional)
 * @param unknown $page        (optional)
 * @param unknown $total_pages (optional)
 * @return string
 */
function array2json($array=[], $id_index=0, $count=0, $page=1, $total_pages=1) {
  // format array to jqgrid json
  foreach ((array)$array as $r) {
    $rows[] = array(
      'id' => $r[$id_index],
      'cell' => $r
    );
  };
  return jqgridWrap($rows, $count, $page, $total_pages);
}


/**
 * konversi array biasa ke dalam format jqGrid,
 * kolom pertama dihilangkan dari row, menjadi key
 *
 * @author Azrul Azwar
 * @param unknown $array
 * @param unknown $count       (optional)
 * @param unknown $page        (optional)
 * @param unknown $total_pages (optional)
 * @return string
 */
function arrayh2json($array, $count=0, $page=1, $total_pages=1) {
  // format array to jqgrid json
  foreach ((array)$array as $r) {
    $id = array_shift($r);
    $rows[] = array(
      'id' => $id,
      'cell' => $r
    );
  };
  return jqgridWrap($rows, $count);
}


/**
 * konversi array biasa ke dalam format jqGrid,
 * Array tidak mempunyai key, dibuatkan key nomor urut
 *
 * @author Azrul Azwar
 * @param unknown $array
 * @param unknown $count       (optional)
 * @param unknown $page        (optional)
 * @param unknown $total_pages (optional)
 * @return string
 */
function arrayi2json($array, $count=0, $page=1, $total_pages=1) {
  // format array to jqgrid json
  $i=1;
  foreach ((array)$array as $r) {
    $rows[] = array(
      'id' => $i++,
      'cell' => $r
    );
  };
  return jqgridWrap($rows, $count);
}


/**
 * Membuat list bulan dan tahun, digunakan untuk membuat query bulanan
 *
 * @author Azrul Azwar
 * @param unknown $year 
 * @param unknown $nyear jumlah tahun      (optional)
 * @param unknown $withCurrent termasuk bulan sekarang(optional)
 * @return array
 */
function monthList($year, $nyear=1, $withCurrent=false) {
  $cyear = date('Y');
  $month = date('m');

  if ($cyear != $year) {
    $startYear = $year-$nyear+1;
    $startMonth = 1;
  } else {
    $startYear = $year-$nyear;
    if ($withCurrent) {
      $month++;
      if ($month>12) {
        $month = 1;
        $startYear++;
      }
    }
    $startMonth = $month;
  }

  for ($i=0;$i<$nyear;$i++) {
    for ($j=0;$j<12;$j++) {
      $runYear = $startYear + $i;
      $runMonth = $startMonth + $j;
      if ($runMonth>12) {
        $runYear++;
        $runMonth -= 12;
      }
      $iterator[$i][] = [$runYear, $runMonth];
    }
  }
  if ($nyear==1) return $iterator[0];
  else return $iterator;
}


/**
 * Membuat list interval bulan
 *
 * @author Azrul Azwar
 * @param unknown $year
 * @param unknown $nyear       (optional)
 * @param unknown $withCurrent (optional)
 * @return void
 */
function monthIntervalList($year, $nyear=1, $withCurrent=false) {
  foreach (monthList($year, $nyear, $withCurrent) as $ym) {
    $start = sprintf('%04d-%02d-01', $ym[0], $ym[1]);
    $end = date('Y-m-t', strtotime($start));
    $result[] = [$start, $end];
  }
  return $result;
}


/**
 *
 * @param unknown $value
 * @return unknown
 */
function sign($value) {
  if ($value < 0) return -1;
  if ($value > 0) return 1;
  return 0;
}


?>
