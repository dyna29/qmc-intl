<?php
/**
 * app/controllers/fuwafuwa/ajaxcontroller.php
 *
 * @package default
 */


namespace Fuwafuwa;

new Db(); // supaya autoload

class AjaxController extends Controller {

  /**
   *
   * @param unknown $key
   * @param unknown $reset
   */
  protected function retrieveCache($key, $reset) {
    $cache = \Cache::instance();
    $key = $this->safe_key($key) . ".txt";
    if ($reset) $cache->clear($key);
    if ($result = $cache->get($key)) {
      print $result;
      die(); // This is ajax, so no problem with unfinished html
    };
  }





  /**
   *
   * @param unknown $f3
   * @param unknown $action
   */
  function execute($f3, $action) {
    header('Content-type: application/json');
    $access = \Access::instance();
    if (method_exists($this, $action)) {
      if ($access->authorize($f3['SESSION.group'])) {
        $this->request = $f3['REQUEST'];
        $this->$action();
      } else {
        $f3->error(403);
      }
    } else {
      die(t('METHOD_TIDAK_ADA', __CLASS__ . "\\$action"));
    }
  }





  /**
   * Generic ajax function for jqGrid add/edit/del
   *
   * @author Azrul Azwar
   * @param string  $class
   * @param string  $pk
   * @param unknown $del   (optional)
   * @return void
   */
  function ajaxEdit($class, $pk, $del=true) {
    extract($this->request); // kode
    if (is_array($pk)) {
      foreach ($pk as $k) {
        $keys[] = $$k;
      }
      $record = $class::instance($keys);
    } else {
      $record = $class::instance($$pk);
    }
    $result['success'] = true;
    $result['id'] = $$pk;
    switch ($oper) {
    case 'add':
      if (!$record->dry()) {
        $result['success'] = false;
        if (is_array($pk)) {
          foreach ($pk as $k) {
            $keys[] = $$k;
          }
          $key = join(', ', $keys);
        } else {
          $key = $$pk;
        }
        $record['message'] = t('REKAMAN_GANDA', $record->table(), $key);
      } else {
        $record->saveFromRequest();
      }
      break;
    case 'edit':
      $record->saveFromRequest();
      break;
    case 'del':
      if (!$del) {
        $result['success'] = false;
        $result['message'] = t('DILARANG_HAPUS');
      } else {
        $record->erase();
      }
      break;
    default:
      // code...
      break;
    }
    print json_encode($result);
  }


}


?>
