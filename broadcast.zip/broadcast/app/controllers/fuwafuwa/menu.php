<?php
/**
 * app/controllers/fuwafuwa/menu.php
 *
 * @package default
 */


namespace Fuwafuwa;

class Menu {

  /**
   * Definisi menu, untuk permission diset di bagian Access
   */
  private $menudef;


  /**
   *
   */
  function __construct() {
    $f3 = \Base::instance();
    if ($menuFile = $f3['APP.menuFile']) {
      $menuFile .= "." . strtolower($f3['APP.lang']);
      $this->menudef = $this->readTextMenu($menuFile);
    }
  }


  /**
   *
   * Format menu:
   * inden 2 spasi
   * Parent menu cukup nama
   * sub menu: menu | title | url
   * contoh:
   * Laporan
   *   Keuangan
   *     Jurnal | Laporan Jurnal Keuangan | laporan/jurnal/keuangan
   *     Transaksi | Laporan Transaksi Keuangan | laporan/transaksi/keuangan
   *
   * @param unknown $file
   * @return unknown
   */
  function readTextMenu($file) {
    $f3 = \Base::instance();
    $menu = [];
    $parent[0] = &$menu;
    $clevel = 0;
    $input = explode("\n", file_get_contents("$f3[ROOT]$f3[BASE]/$file"));
    foreach ($input as $i) {
      if (preg_match('/^\s*$/', $i)) continue; // baris kosong
      
      //preg_match('/^( *)(.*?)(\s*\|\s*(.*))?$/', $i, $m);
      preg_match('/^( *)(.*)$/', $i, $m);
      $level = strlen($m[1])/2;
      if ($level != $clevel) {
        if ($level > $clevel) {
          if ($level > 1) {
            $idx =  count($parent[$clevel]['submenu']) -1;
            $parent[$level] = &$parent[$clevel]['submenu'][$idx];
          } else {
            $idx = count($menu) -1;
            $parent[$level] = &$menu[$idx];
          }
          $parent[$level] = $level > 1 ? end($parent[$clevel]['submenu']): end($menu);
        }
        $clevel = $level;
      }
      if ($level < 1) {
        $menu[] = ['title' => $m[2]];
      } else {
        list($mtitle, $page_title, $url) = preg_split('/\s+\|\s+/', $m[2]);
        $parent[$level]['submenu'][] = ['title' => $mtitle, 'page_title' => $page_title, 'url' => $url];
      }
    }
    return $menu;
  }



  /**
   * Memberi tanda suatu menu untuk ditampilkan atau tidak, berdasarkan group permission
   *
   * @author Azrul Azwar
   * @param unknown $group
   * @return void
   */
  private function flagMenuForGroup($group) {
    $cache = \Cache::instance();
    if (!function_exists('processSub')) {


      /**
       *
       * @param unknown $menu  (reference)
       * @param unknown $group
       * @return unknown
       */
      function processSub(&$menu, $group) {
        foreach ($menu as &$m) {
          if ($m['submenu']) {
            processSub($m['submenu'], $group);
            $m['enabled'] = array_reduce($m['submenu'], function($c, $a) { $c += $a['enabled']; return $c; }, 0);
          } else {
            $m['enabled'] = intval(\Access::instance()->granted("GET /$m[url]", $group));
          }
        }
      }


    }
    processSub($this->menudef, $group);
  }





  /**
   *
   * @param unknown $url
   */
  function title($url) {


    /**
     *
     * @param unknown $menu
     * @param unknown $url
     * @return unknown
     */
    function search($menu, $url) {
      foreach ($menu as $m) {
        if ($m['submenu']) {
          $result = search($m['submenu'], $url);
        } else {
          $result = $m['url'] == $url ? $m['page_title'] : '';
        }
        if ($result) return $result;
      }
    }


    return search($this->menudef, $url);
  }


  /**
   * Mencetak menu sesuai group permission
   *
   * @author Azrul Azwar
   * @param string  $group
   * @return void
   */
  function printMenu($group) {
    $cache = \Cache::instance();
    $theme = ucfirst(\Base::instance()->get('APP.theme'));
    $key = "menu.$group";
    if ($result = $cache->get($key)) {
      print $result;
      return;
    }

    $this->flagMenuForGroup($group);
    $level = 1;

    if ($theme) {
      $printSubmenu = "\\Theme\\$theme::printSubmenu";
    } else {
      $printSubmenu = "\\Theme::printSubmenu";
    }

    print "<!-- printsub: $printSubmenu -->";
    $result = call_user_func($printSubmenu, $this->menudef, $level, $group);

    \Cache::instance()->set($key, $result, 3600*24); // 1 day caching
    print $result;
  }





  /**
   * Mencetak menu sesuai group permission
   *
   * @author Azrul Azwar
   * @param string  $group
   * @return void
   */
  function printMenuMobile($group) {
    $cache = \Cache::instance();
    $theme = ucfirst(\Base::instance()->get('APP.theme'));
    $key = "m-menu.$group";
    if ($result = $cache->get($key)) {
      print $result;
      return;
    }

    $this->flagMenuForGroup($group);
    $level = 1;

    if ($theme) {
      $printSubmenu = "\\Theme\\$theme::printSubmenuMobile";
    } else {
      $printSubmenu = "\\Theme::printSubmenuMobile";
    }

    print "<!-- printsub: $printSubmenu -->";
    $result = call_user_func($printSubmenu, $this->menudef, $level, $group);

    \Cache::instance()->set($key, $result, 3600*24); // 1 day caching
    print $result;
  }


}


?>
