<?php
namespace Ajax;

class Emergency extends \Fuwafuwa\AjaxController {
  function report() {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    $record = new \Model\Emergency();
    $record->copyFrom($data);
    $record->save();
    $person = \Model\Person::instance($data['nid']);
    
    $f3 = \Base::instance();
    $f3['name'] = $person['name'];
    $f3['phone'] = $person['phone'];
    $f3['cause'] = $data['subject'] . ", " . $data['additional'];
    $message = \Template::instance()->render('email/emergency.htm');
    $subject = "Emergency Call";
    $this->notify_email($subject, $message);
  }
  
  function safety() {
    $json = file_get_contents('php://input'); // oid, nid, safe, location
    $data = json_decode($json, true);
    if(!$data['oid'] || !$data['nid']) die();
    if(FSQL1('SELECT COUNT(1) FROM safety_report WHERE oid = ? AND nid = ?', $data['oid'], $data['nid'])) {
      SQL('UPDATE safety_report SET safe = ?, location = ? WHERE oid = ? AND nid = ?', 
        $data['safe'], $data['location'], $data['oid'], $data['nid']);
    } else {
      SQL('INSERT INTO safety_report(oid, nid, safe, location) VALUES(?,?,?,?)', 
        $data['oid'], $data['nid'], $data['safe'], $data['location']);
    }
    if($data['safe'] == 0) {
      $person = \Model\Person::instance($data['nid']);
      $occurence = \Model\Occurence::instance($data['oid']);
      $f3 = \Base::instance();
      $f3['name'] = $person['name'];
      $f3['phone'] = $person['phone'];
      $f3['event'] = $occurence['type'] . " – " . $occurence['location'];
      $message = \Template::instance()->render('email/safety.htm');
      $subject = "Help Needed in $occurence[type]";
      $this->notify_email($subject, $message);
    }
  }
  
  function occurence() {
    print(json_encode(SQL('SELECT * FROM occurence WHERE status = 1')));
  }
  
  private function notify_email($subject, $message) {
    $f3 = \Base::instance();
    $smtp = new \SMTP($f3['SMTP.host'], $f3['SMTP.port'], $f3['SMTP.scheme'], $f3['SMTP.user'], $f3['SMTP.pass']);
    $smtp->set('From', $f3['SMTP.from']);
    $email = $f3['COMPANY.admin'];
    if(is_array($email)) $email = join(", ", $email);
    $smtp->set('To', $email);
    $smtp->set('Subject', $subject);
    $smtp->send($message);
  }
  
  function test() {
    $this->notify_email('Test', 'Test message');
  }
}
