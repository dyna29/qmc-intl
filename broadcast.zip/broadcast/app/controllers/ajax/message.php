<?php
namespace Ajax;

class Message extends \Fuwafuwa\AjaxController {
  private function gen_uuid() {
    return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
      // 32 bits for "time_low"
      mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
      // 16 bits for "time_mid"
      mt_rand( 0, 0xffff ),
      // 16 bits for "time_hi_and_version",
      // four most significant bits holds version number 4
      mt_rand( 0, 0x0fff ) | 0x4000,
      // 16 bits, 8 bits for "clk_seq_hi_res",
      // 8 bits for "clk_seq_low",
      // two most significant bits holds zero and one for variant DCE1.1
      mt_rand( 0, 0x3fff ) | 0x8000,
      // 48 bits for "node"
      mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
    );
  }
  
  function register() {
    $json = file_get_contents('php://input'); // push_token
    $data = json_decode($json, true);
    print SQL('INSERT OR IGNORE INTO device (push_token) VALUES(?)', $data['push_token']);
  }
  
  private function send_notification($data) {
    $ch = curl_init();

    // Set cURL opts
    curl_setopt($ch, CURLOPT_URL, 'https://exp.host/--/api/v2/push/send');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'accept: application/json',
        'content-type: application/json',
    ]);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = [
      'body' => curl_exec($ch),
      'status_code' => curl_getinfo($ch, CURLINFO_HTTP_CODE)
    ];

    return json_decode($response['body'], true)['data'];
  }
  
  function broadcast() {
    extract($this->request); // type, title, body
    
    $tokens = FSQLC('SELECT DISTINCT push_token FROM device WHERE push_token IS NOT NULL');
    $data = array_map(function($el) use ($title, $body) { 
      return [
        "data" => ["link" => $link, "type" => "broadcast"], 
        "to" => $el, 
        "title" => $title, 
        "body" => $body,
        "sound" => "default",
      ];
      }, 
      $tokens);
    foreach(array_chunk($data, 100) as $chunk) {
      $status = $this->send_notification($chunk);
      foreach($status as $i => $s) {
        if($s['status'] != 'ok') {
          SQL('UPDATE device SET error = error + 1 WHERE push_token = ?', $tokens[$i]);
        }
      }
      print_r($status);
    }
  }
  
  function broadcast_list() {
    $message = (array) FSQL('SELECT * FROM broadcast ORDER BY date DESC');
    print(json_encode($message));
  }
}