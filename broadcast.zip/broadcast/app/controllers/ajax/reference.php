<?php
/**
 * app/controllers/ajax/reference.php
 *
 * @package default
 */


namespace Ajax;

class Reference extends \Fuwafuwa\AjaxController {
  function occurence_list() {
    $list = SQL("SELECT oid as 'id', type || ' – ' || location as 'text' FROM occurence ORDER BY oid DESC LIMIT 10");
    print json_encode($list);
  }
}