<?php
/**
 * app/controllers/ajax/laporan/penjualan.php
 *
 * @package default
 */


namespace Ajax\Laporan;

class Safety extends \Fuwafuwa\AjaxController {
  function list1() {
    extract($this->request);
    $lcond[] = "s.oid = $oid";
    if($safe != "") $lcond[] = "safe = $safe";
    if($ptype) $lcond[] = "p.type = '$ptype'";
    $where = "WHERE " . implode(" AND ", $lcond);
    $sql = "SELECT s.nid, p.nid as mnid, name, address, email, phone, safe, s.location as user_loc, report_date
      FROM safety_report s
			JOIN person p ON s.nid = p.nid
      JOIN occurence o ON o.oid = s.oid
      $where";      
    $res = FSQL($sql);
    array2json($res);    
  }
}
