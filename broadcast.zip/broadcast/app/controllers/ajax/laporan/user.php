<?php
/**
 * app/controllers/ajax/laporan/user.php
 *
 * @package default
 */


namespace Ajax\Laporan;

class User extends \Fuwafuwa\AjaxController {


  /**
   *
   */
  function list1() {
    extract($this->request);
    $sql = "SELECT login, fullname, role, password FROM user";
    $res = FSQL($sql);
    arrayi2json($res);
  }


}


?>
