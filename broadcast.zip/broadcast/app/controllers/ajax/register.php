<?php
/**
 * app/controllers/ajax/maintenance.php
 *
 * @package default
 */


namespace Ajax;

class Register extends \Fuwafuwa\AjaxController {


  /**
   *
   * @return unknown
   */
  function student_info() {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    $data = SQL('SELECT * FROM student WHERE nid = ?', $data['nid']);
    $student = $data[0];
    if($student) {      
      $student['address'] = "$student[pref]$student[address] $student[post]";
      print(json_encode(['data' => $student]));
      die();
    }
    print(json_encode(['error' => 'الطالب/ـة غير موجود']));
  }
  
  function person() {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    $exist = FSQL1('SELECT COUNT(1) FROM person WHERE (nid = ? OR email = ?) AND active = 1', 
      $data['nid'], $data['email']);
    if($exist) {
      print(json_encode(['error' => 'تم تسجيل المستخدم أو البريد الإلكتروني']));
      die();
    }
    // if no active yet, can be override
    SQL('DELETE FROM person WHERE (nid = ? OR email = ?)', $data['nid'], $data['email']);
    
    $pin = rand(100000,999999);
    $token = md5($data['email']);
    SQL('INSERT INTO person(nid,name,address,phone,email,type,sid,pin,token,push_token) 
      VALUES(?,?,?,?,?,?,?,?,?,?)',
      $data['nid'], $data['name'], $data['address'], $data['phone'], $data['email'], 
      $data['type'], $data['sid'], $pin, $token, $data['push_token']);
    $data['pin'] = $pin;
    $data['token'] = $token;
    
    $this->send_activation_email($data['email'], $token);
    
    print(json_encode(['data' => $data]));
  }
  
  function status() {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    $active = FSQL1('SELECT COUNT(1) FROM person WHERE nid = ? AND active = 1', $data['nid']);
    print(json_encode(["active" => boolval($active)]));
  }
  
  function resend_email() {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    $data = FSQLR('SELECT email, token FROM person WHERE nid = ?', $data['nid']);
    if($email && $token) {
      $this->send_activation_email($email, $token);
      print(json_encode(["success" => true, "message" => "تم ارسال البريد الالكتروني"]));
    } else {
      print(json_encode(["success" => false, "message" => "الحساب غير صحيح"]));
    }
  }
  
  private function send_activation_email($email, $token) {
    $f3 = \Base::instance();    
    $f3['link'] = 'https://' . $f3['HOST'] . $f3['BASE'] . "/ajax/register/verify?token=$token";
    $message = \Template::instance()->render('email/verification.htm');
    $subject = "التحقق من التسجيل";
    $this->send_email($email, $subject, $message);
    // $this->send_email("mahana@saudiculture.jp", $subject, $message);
  }

  function verify() {
    extract($this->request);
    SQL('UPDATE person SET active = 1 WHERE token = ?', $token);
    print "";
  }
  
  private function send_email($to, $subject, $message) {
    $f3 = \Base::instance();
    $smtp = new \SMTP($f3['SMTP.host'], $f3['SMTP.port'], $f3['SMTP.scheme'], $f3['SMTP.user'], $f3['SMTP.pass']);
    $smtp->set('From', $f3['SMTP.from']);
    $smtp->set('To', $to);
    $smtp->set('Subject', $subject);
    $smtp->send($message);
  }
  
  function test() {    
    $f3 = \Base::instance();
    $link = 'https://' . $f3['HOST'] . $f3['BASE'] . "/ajax/register/verify?token=";
    $f3['link'] = $link;
    echo \Template::instance()->render('email/verification.htm');
  }

  /**
   * push_token
   * Register push token of a user
   * @return void
   * @author Azwar Azrul
   */
  function push_token() {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    SQL('UPDATE person SET push_token = ? WHERE nid = ?', $data['push_token'], $data['nid']);
    print(json_encode($data));
  }
  
  function from_file() {
    $file = "students.csv";
    $csv = array_map(function($e){ return str_getcsv($e, ";" ); }, file($file));
    array_shift($csv); # remove column header
    SQL('DELETE FROM student');
    foreach($csv as $d) {
      SQL('INSERT INTO student VALUES(?,?,?,?,?,?,?)', $d[0], $d[1], $d[2], $d[3], $d[4], $d[5], $d[6]);
    }
  }
}


?>
