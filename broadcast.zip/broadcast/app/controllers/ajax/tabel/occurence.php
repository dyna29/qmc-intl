<?php
/**
 * app/controllers/ajax/tabel/barang.php
 *
 * @package default
 */


namespace Ajax\Tabel;

class Occurence extends \Fuwafuwa\AjaxController {


  /**
   *
   */
  function list1() {
    $fields = "id, type, location, description, date, status";
    record_list('occurence',$fields);
  }


  function edit() {
    $f3 = \Base::instance();
    if($f3['REQUEST.oper'] == 'add') {
      $f3->clear('REQUEST.id');
      $this->broadcast($f3['REQUEST.type'], $f3['REQUEST.location'], $f3['REQUEST.description']);
    }
    parent::ajaxEdit('\Model\Occurence', 'id');
  }
  
  private function broadcast($type, $location, $description) {
    $f3 = \Base::instance();
    switch ($type) {
      case 'earthquake': $type = 'زلزال'; break;
      case 'typhoon': $type = 'إعصار'; break;
      case 'volcano': $type = 'بركان'; break;
      case 'flood': $type = 'فيضان'; break;
      case 'other': $type = 'أخرى'; break;
      default: break;
    }
    $id = FSQL1('SELECT MAX(id) FROM broadcast');
    $post = [
      'type' => 'occurence',
      'title' => "$type – $location",
      'body' => $description,      
    ];
    //$url = 'https://sandbox.fuwafuwa.web.id/emergency-web/ajax/chat/broadcast';
    $url = 'https://' . $f3['HOST'] . $f3['BASE'] . "/ajax/chat/broadcast";
    $options = [
      CURLOPT_URL        => $url,
    	CURLOPT_POST       => true,
    	CURLOPT_POSTFIELDS => $post,
    ];
    $ch = curl_init();
    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);
    //error_log(print_r($response, true));
    curl_close($ch);
  }
}
