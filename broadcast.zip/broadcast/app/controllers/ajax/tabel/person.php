<?php
/**
 * app/controllers/ajax/tabel/barang.php
 *
 * @package default
 */


namespace Ajax\Tabel;

class Person extends \Fuwafuwa\AjaxController {


  /**
   *
   */
  function list1() {
    extract($this->request); // type    
    if($type) {
      $conds = ["type = '$type'"];
    }
    $fields = "nid, nid as mnid, type, name, address, email, phone, active, register_date, pin, token, push_token";
    record_list('person',$fields,$conds);
  }


  function edit() {
    parent::ajaxEdit('\Model\Student', 'nid');
  }

}
