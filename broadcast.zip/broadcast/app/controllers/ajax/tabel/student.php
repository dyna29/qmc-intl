<?php
/**
 * app/controllers/ajax/tabel/barang.php
 *
 * @package default
 */


namespace Ajax\Tabel;

class Student extends \Fuwafuwa\AjaxController {


  /**
   *
   */
  function list1() {
    $fields = "nid, name, post, pref, address, email, phone";
    record_list('student', $fields);
  }


  function edit() {
    parent::ajaxEdit('\Model\Student', 'kode');
  }

}
