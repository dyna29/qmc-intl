<?php
/**
 * app/controllers/ajax/tabel/barang.php
 *
 * @package default
 */


namespace Ajax\Tabel;

class Emergency extends \Fuwafuwa\AjaxController {


  /**
   *
   */
  function list1() {
    $fields = "eid, e.nid, name, subject, additional, location, call_time";
    $from_join = "emergency_call e
			JOIN person p ON e.nid = p.nid";
    record_list2(
      $from_join,
      $fields,
      [],
      ['e.nid' => 'nid'],
      "SELECT count(1) FROM emergency_call"
    );
  }


  function edit() {
    parent::ajaxEdit('\Model\Emergency', 'eid');
  }

}
