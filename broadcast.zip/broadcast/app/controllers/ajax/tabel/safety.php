<?php
/**
 * app/controllers/ajax/tabel/barang.php
 *
 * @package default
 */


namespace Ajax\Tabel;

class Safety extends \Fuwafuwa\AjaxController {


  /**
   *
   */
  function list1() {
    $fields = "s.oid, o.type, location, name, safe, report_date";
    $from_join = "safety_report s
			JOIN person p ON s.nid = p.nid
      JOIN occurence o ON o.oid = s.oid";
    record_list2(
      $from_join,
      $fields,
      [],
      ['s.oid' => 'oid', 'o.type' => 'type'],
      "SELECT count(1) FROM safety_report"
    );
  }


  function edit() {
    parent::ajaxEdit('\Model\SafetyReport', ['oid','nid']);
  }

}
