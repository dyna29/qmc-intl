<?php
/**
 * app/controllers/ajax/tabel/barang.php
 *
 * @package default
 */


namespace Ajax\Tabel;

class Broadcast extends \Fuwafuwa\AjaxController {


  /**
   *
   */
  function list1() {
    record_list('broadcast', "id, title, text, link, date");
  }


  function edit() {
    parent::ajaxEdit('\Model\Broadcast', 'id');
  }

  function device_list() {
    record_list('device', 'id, push_token, active, error, created');
  }
}
