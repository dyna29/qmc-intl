#!/bin/bash
sync_up () {
  rsync -avz --delete --exclude=fuwafuwa.db --exclude=tmp --exclude=.git --exclude=sync.sh --rsync-path='./bin/rsync' -e 'ssh -p 65002' ./ fuwafuwa@fuwafuwa.web.id:www/sandbox/broadcast/
}

sync_down () {
  rsync -avz --exclude=tmp --exclude=.git --exclude=sync.sh --rsync-path='./bin/rsync' -e 'ssh -p 65002' fuwafuwa@fuwafuwa.web.id:www/sandbox/broadcast/ ./
}

if [ "$1" == 'd' ]
then
  sync_down
else
  sync_up
fi